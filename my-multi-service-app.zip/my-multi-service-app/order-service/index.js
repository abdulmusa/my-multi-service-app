const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const app = express();
const port = 5003;

app.use(bodyParser.json());

mongoose.connect('mongodb://mongo:27017/multiservice', { useNewUrlParser: true, useUnifiedTopology: true });

const OrderSchema = new mongoose.Schema({
  productId: mongoose.Schema.Types.ObjectId,
  quantity: Number,
  status: String,
});

const Order = mongoose.model('Order', OrderSchema);

app.post('/orders', async (req, res) => {
  const { productId, quantity, status } = req.body;
  const order = new Order({ productId, quantity, status });
  await order.save();
  res.json({ message: 'Order created!', order });
});

app.get('/orders', async (req, res) => {
  const orders = await Order.find();
  res.json(orders);
});

app.listen(port, () => {
  console.log(`Order service listening at http://localhost:${port}`);
});
